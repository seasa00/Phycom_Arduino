#define TEMP_PIN A1

void setup() {
  Serial.begin(9600);

  analogReference(AR_INTERNAL);
  analogReadResolution(12);
}

void loop() {
  int raw = analogRead(TEMP_PIN);

  float voltage = raw * (1.5 / 4095.0);
  float temperature = (voltage - 0.5) * 100.0;

  Serial.print("ADC: ");
  Serial.print(raw);

  Serial.print(" | Voltage: ");
  Serial.print(voltage, 4);

  Serial.print(" | Temperature: ");
  Serial.println(temperature, 2);

  delay(1000);
}