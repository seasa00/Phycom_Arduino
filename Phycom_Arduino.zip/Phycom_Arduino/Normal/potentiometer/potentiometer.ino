#define POT_PIN A0

void setup() {
  Serial.begin(9600);
  analogReadResolution(10); // 0–1023
}

void loop() {
  int potValue = analogRead(POT_PIN);

  Serial.print("Potentiometer: ");
  Serial.println(potValue);

  delay(200);
}