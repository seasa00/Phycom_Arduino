// ========== EDIT HERE ==========
const int segPins[7] = {2, 3, 4, 5, 6, 7, 8};

// false = Common Cathode
// true  = Common Anode
const bool COMMON_ANODE = false;
// ===============================

// Segments: a b c d e f g
const byte digits[10][7] = {
  {1,1,1,1,1,1,0}, // 0
  {0,1,1,0,0,0,0}, // 1
  {1,1,0,1,1,0,1}, // 2
  {1,1,1,1,0,0,1}, // 3
  {0,1,1,0,0,1,1}, // 4
  {1,0,1,1,0,1,1}, // 5
  {1,0,1,1,1,1,1}, // 6
  {1,1,1,0,0,0,0}, // 7
  {1,1,1,1,1,1,1}, // 8
  {1,1,1,1,0,1,1}  // 9
};

void displayNumber(int num) {
  if (num < 0 || num > 9) return;

  for (int i = 0; i < 7; i++) {
    bool on = digits[num][i];
    digitalWrite(segPins[i],
                 (on != COMMON_ANODE) ? HIGH : LOW);
  }
}

void setup() {
  Serial.begin(9600);

  for (int i = 0; i < 7; i++) {
    pinMode(segPins[i], OUTPUT);
  }
}

void loop() {
  for (int num = 0; num <= 9; num++) {
    displayNumber(num);

    Serial.print("Number: ");
    Serial.println(num);

    delay(1000);
  }
}