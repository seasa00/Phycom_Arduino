#include <math.h>

// ===== EDIT HERE =====
#define THERM_PIN A0

const float R_FIXED = 10000.0;
const float R_NOMINAL = 10000.0;
const float BETA = 3950.0;
// =====================

float readTemperature() {
  int raw = analogRead(THERM_PIN);

  if (raw <= 0 || raw >= 1023) {
    return NAN;
  }

  // Calculate Thermistor Resistance
  float resistance = R_FIXED * raw / (1023.0 - raw);

  // Calculate Temperature (Celsius)
  float tempK = 1.0 / (
    (1.0 / 298.15) +
    (log(resistance / R_NOMINAL) / BETA)
  );

  return tempK - 273.15;
}

void setup() {
  Serial.begin(9600);
  analogReadResolution(10);
}

void loop() {
  float temperature = readTemperature();

  Serial.print("Temperature: ");
  Serial.print(temperature, 2);
  Serial.println(" C");

  delay(1000);
}