#define TEMP_PIN A0

void setup() {
  Serial.begin(9600);
  analogReadResolution(10);
}

void loop() {
  // ===== READ TEMPERATURE =====
  int rawValue = analogRead(TEMP_PIN);

  float voltage = rawValue * (5.0 / 1023.0);
  float temperature = (voltage - 0.5) * 100.0;

  // ===== SERIAL MONITOR =====
  Serial.print("Temperature: ");
  Serial.print(temperature, 2);
  Serial.println(" C");

  delay(1000);
}