#include <Arduino.h>
#include <WiFiS3.h>
#include <PubSubClient.h>

// ================= EDIT HERE =================
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic_pub = "68070091/keypad";
// =============================================

// ================= MQTT =================
WiFiClient wifiClient;
PubSubClient client(wifiClient);

// ================= KEYPAD =================
const byte ROWS = 4;
const byte COLS = 4;

char keys[ROWS][COLS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

// Left = Row, Right = Column
byte rowPins[ROWS] = {9, 8, 7, 6};
byte colPins[COLS] = {5, 4, 3, 2};

// ================= DEBOUNCE =================
const unsigned long debounceDelay = 50;

char lastRawKey = '\0';
char stableKey = '\0';

unsigned long lastChangeTime = 0;

// ================= SCAN KEYPAD =================
char scanKeypad() {
  char detectedKey = '\0';
  byte pressedCount = 0;

  for (byte c = 0; c < COLS; c++) {

    digitalWrite(colPins[c], LOW);
    pinMode(colPins[c], OUTPUT);
    delayMicroseconds(20);

    for (byte r = 0; r < ROWS; r++) {
      if (digitalRead(rowPins[r]) == LOW) {
        detectedKey = keys[r][c];
        pressedCount++;
      }
    }

    pinMode(colPins[c], INPUT);
  }

  if (pressedCount == 1) {
    return detectedKey;
  }

  return '\0';
}

// ================= MQTT RECONNECT =================
void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting MQTT...");

    String clientId = "Arduino_Keypad_";
    clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("Connected!");
    } else {
      Serial.print("Failed, rc=");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

// ================= SETUP =================
void setup() {
  Serial.begin(9600);

  // ---------- KEYPAD ----------
  for (byte r = 0; r < ROWS; r++) {
    pinMode(rowPins[r], INPUT_PULLUP);
  }

  for (byte c = 0; c < COLS; c++) {
    pinMode(colPins[c], INPUT);
  }

  Serial.println("Keypad Ready!");

  // ---------- WIFI ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(500);
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
}

// ================= LOOP =================
void loop() {

  // ---------- MQTT ----------
  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  // ---------- SCAN KEYPAD ----------
  char rawKey = scanKeypad();

  if (rawKey != lastRawKey) {
    lastRawKey = rawKey;
    lastChangeTime = millis();
  }

  // ---------- DEBOUNCE ----------
  if (millis() - lastChangeTime >= debounceDelay) {

    if (rawKey != stableKey) {
      stableKey = rawKey;

      if (stableKey != '\0') {

        // ===== CONVERT KEY TO STRING =====
        char message[2] = {stableKey, '\0'};

        // ===== MQTT PUBLISH =====
        bool success = client.publish(topic_pub, message);

        // ===== SERIAL MONITOR =====
        Serial.print("Key Detected: ");
        Serial.print(stableKey);

        Serial.print(" | MQTT: ");
        Serial.println(success ? "Published" : "Failed");
      }
    }
  }
}