#include <WiFiS3.h>
#include <PubSubClient.h>

// ========== EDIT HERE ==========
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic = "68070091/temp";

#define TEMP_PIN A0

const unsigned long publishInterval = 1000;
// ===============================

WiFiClient wifiClient;
PubSubClient client(wifiClient);

unsigned long previousMillis = 0;

// ---------- READ TEMPERATURE ----------
float readTemperature() {
  int rawValue = analogRead(TEMP_PIN);

  float voltage = rawValue * (5.0 / 1023.0);
  float temperature = (voltage - 0.5) * 100.0;

  return temperature;
}

// ---------- MQTT RECONNECT ----------
void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting MQTT...");

    String clientId = "Arduino_Temp_";
    clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("Connected!");
    } else {
      Serial.print("Failed, rc=");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(9600);
  analogReadResolution(10);

  // ---------- WIFI ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(500);
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  if (millis() - previousMillis >= publishInterval) {
    previousMillis = millis();

    // ===== READ TEMPERATURE =====
    float temperature = readTemperature();

    // ===== CONVERT TO TEXT =====
    char message[20];
    dtostrf(temperature, 1, 2, message);

    // ===== MQTT PUBLISH =====
    bool success = client.publish(topic, message);

    // ===== SERIAL MONITOR =====
    Serial.print("Temperature: ");
    Serial.print(message);
    Serial.print(" C | MQTT: ");
    Serial.println(success ? "Published" : "Failed");
  }
}