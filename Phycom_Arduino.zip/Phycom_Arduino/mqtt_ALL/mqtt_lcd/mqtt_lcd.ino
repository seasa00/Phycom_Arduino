#include <WiFiS3.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ========== EDIT HERE ==========
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic_sub = "68070091/prob_stat";

LiquidCrystal_I2C lcd(0x27, 16, 2);
// ===============================

WiFiClient wifiClient;
PubSubClient client(wifiClient);

// ---------- MQTT CALLBACK ----------
void callback(char* topic, byte* payload,
              unsigned int length) {

  char message[64];

  if (length >= sizeof(message)) return;

  memcpy(message, payload, length);
  message[length] = '\0';

  // ===== LCD DISPLAY =====
  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print("MQTT Received:");

  lcd.setCursor(0, 1);
  lcd.print(message);

  // ===== SERIAL MONITOR =====
  Serial.print("Received: ");
  Serial.println(message);
}

// ---------- MQTT RECONNECT ----------
void reconnect() {
  while (!client.connected()) {
    String clientId = "Arduino_LCD_";
    clientId += String(random(0xffff), HEX);

    Serial.print("Connecting MQTT...");

    if (client.connect(clientId.c_str())) {
      Serial.println("Connected!");

      // ===== MQTT SUBSCRIBE =====
      client.subscribe(topic_sub);
    }
    else {
      Serial.print("Failed: ");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(9600);

  // ---------- LCD ----------
  Wire.begin();
  lcd.init();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("Connecting...");

  // ---------- WIFI ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);

  lcd.clear();
  lcd.print("Waiting MQTT...");
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();
}