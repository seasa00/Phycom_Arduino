#include <WiFiS3.h>
#include <PubSubClient.h>

// ========= EDIT HERE =========
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic = "68070091/emailspin";

#define POT_PIN A0
// =============================

WiFiClient wifiClient;
PubSubClient client(wifiClient);

unsigned long previousMillis = 0;
const unsigned long publishInterval = 200;

// ---------- MQTT Connection ----------
void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting MQTT...");

    if (client.connect("Arduino_EmailSpin")) {
      Serial.println("Connected!");
    } else {
      Serial.print("Failed, rc=");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(9600);
  analogReadResolution(10);

  // ---------- WiFi ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  if (millis() - previousMillis >= publishInterval) {
    previousMillis = millis();

    // ===== READ POTENTIOMETER =====
    int potValue = analogRead(POT_PIN);

    // ===== CONVERT TO TEXT =====
    char message[10];
    snprintf(message, sizeof(message), "%d", potValue);

    // ===== MQTT PUBLISH =====
    client.publish(topic, message);

    // ===== SERIAL MONITOR =====
    Serial.print("Sensor Value: ");
    Serial.println(message);
  }
}