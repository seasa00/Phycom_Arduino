#include <WiFiS3.h>
#include <PubSubClient.h>

// ========== EDIT HERE ==========
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic_pub = "68070091/door";

#define TRIG_PIN 9
#define ECHO_PIN 10
#define BUTTON_PIN 2

const unsigned long publishInterval = 200;
// ===============================

WiFiClient wifiClient;
PubSubClient client(wifiClient);

unsigned long previousMillis = 0;

// ---------- READ ULTRASONIC ----------
float readDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);

  if (duration == 0) return -1;

  return duration * 0.0343 / 2.0;
}

// ---------- MQTT RECONNECT ----------
void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting MQTT...");

    String clientId = "Arduino_Door_";
    clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("MQTT Connected!");
    } else {
      Serial.print("Failed, rc=");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(9600);

  // ---------- ULTRASONIC ----------
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // ---------- PUSH BUTTON ----------
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  // ---------- WIFI ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  if (millis() - previousMillis >= publishInterval) {
    previousMillis = millis();

    // ===== READ SENSOR =====
    float distance = readDistance();

    // INPUT_PULLUP: LOW = Pressed
    bool buttonPressed = (digitalRead(BUTTON_PIN) == LOW);

    // ===== EDIT IF / ELSE HERE =====
    const char* result;

    if (distance >= 20 && buttonPressed) {
      result = "On";
    }
    else {
      result = "Off";
    }
    // ==============================

    // ===== MQTT PUBLISH =====
    bool success = client.publish(topic_pub, result);

    // ===== SERIAL MONITOR =====
    Serial.print("Distance: ");
    Serial.print(distance, 2);

    Serial.print(" cm | Button: ");
    Serial.print(buttonPressed ? "Pressed" : "Released");

    Serial.print(" | Door: ");
    Serial.print(result);

    Serial.print(" | MQTT: ");
    Serial.println(success ? "Published" : "Failed");
  }
}