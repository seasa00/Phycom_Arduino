#include <WiFiS3.h>
#include <PubSubClient.h>

// ========== EDIT HERE ==========
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic_sub = "68070091/prob_stat";

const int segPins[7] = {2, 3, 4, 5, 6, 7, 8};

// false = Common Cathode
// true  = Common Anode
const bool COMMON_ANODE = false;
// ===============================

WiFiClient wifiClient;
PubSubClient client(wifiClient);

// Segments: a b c d e f g
const byte digits[10][7] = {
  {1,1,1,1,1,1,0}, // 0
  {0,1,1,0,0,0,0}, // 1
  {1,1,0,1,1,0,1}, // 2
  {1,1,1,1,0,0,1}, // 3
  {0,1,1,0,0,1,1}, // 4
  {1,0,1,1,0,1,1}, // 5
  {1,0,1,1,1,1,1}, // 6 (FIXED)
  {1,1,1,0,0,0,0}, // 7
  {1,1,1,1,1,1,1}, // 8
  {1,1,1,1,0,1,1}  // 9
};

// ---------- DISPLAY NUMBER ----------
void displayNumber(int num) {
  if (num < 0 || num > 9) return;

  for (int i = 0; i < 7; i++) {
    bool on = digits[num][i];

    digitalWrite(
      segPins[i],
      (on != COMMON_ANODE) ? HIGH : LOW
    );
  }
}

// ---------- MQTT CALLBACK ----------
void callback(char* topic, byte* payload,
              unsigned int length) {

  char message[20];

  if (length == 0 || length >= sizeof(message)) {
    return;
  }

  memcpy(message, payload, length);
  message[length] = '\0';

  // Accept only a single digit 0-9
  if (length != 1 ||
      message[0] < '0' ||
      message[0] > '9') {
    Serial.println("Invalid number!");
    return;
  }

  int number = message[0] - '0';

  // ===== DISPLAY ON 7-SEGMENT =====
  displayNumber(number);

  Serial.print("Received: ");
  Serial.println(number);
}

// ---------- MQTT RECONNECT ----------
void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting MQTT...");

    String clientId = "Arduino_7SEG_";
    clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("MQTT Connected!");

      // ===== MQTT SUBSCRIBE =====
      if (client.subscribe(topic_sub)) {
        Serial.println("Subscribed!");
      }
    }
    else {
      Serial.print("MQTT Failed: ");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

// ---------- SETUP ----------
void setup() {
  Serial.begin(9600);

  // ---------- 7-SEGMENT ----------
  for (int i = 0; i < 7; i++) {
    pinMode(segPins[i], OUTPUT);

    // Initially OFF
    digitalWrite(
      segPins[i],
      COMMON_ANODE ? HIGH : LOW
    );
  }

  // ---------- WIFI ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(500);
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

// ---------- LOOP ----------
void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();
}