#include <WiFiS3.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ========== EDIT HERE ==========
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic1 = "68070091/queue_chotiphat";
const char* topic2 = "68070091/queue_lapas";
const char* topic3 = "68070091/queue_sumet";

const char* topic_pub = "68070091/sentosa_choice";

#define RED_PIN 10
#define GREEN_PIN 9
#define BLUE_PIN 8

#define COMMON_ANODE true

LiquidCrystal_I2C lcd(0x27, 16, 2);
// ===============================

WiFiClient wifiClient;
PubSubClient client(wifiClient);

// ---------- QUEUE DATA ----------
float q1 = 0;
float q2 = 0;
float q3 = 0;

bool received1 = false;
bool received2 = false;
bool received3 = false;

bool dataUpdated = false;

// ---------- RGB LED ----------
void setColor(int r, int g, int b) {
  if (COMMON_ANODE) {
    r = 255 - r;
    g = 255 - g;
    b = 255 - b;
  }

  analogWrite(RED_PIN, r);
  analogWrite(GREEN_PIN, g);
  analogWrite(BLUE_PIN, b);
}

// ---------- MQTT CALLBACK ----------
void callback(char* topic, byte* payload,
              unsigned int length) {

  char message[32];

  if (length == 0 || length >= sizeof(message)) {
    return;
  }

  memcpy(message, payload, length);
  message[length] = '\0';

  float value = atof(message);

  if (value < 0) return;

  if (strcmp(topic, topic1) == 0) {
    q1 = value;
    received1 = true;
  }
  else if (strcmp(topic, topic2) == 0) {
    q2 = value;
    received2 = true;
  }
  else if (strcmp(topic, topic3) == 0) {
    q3 = value;
    received3 = true;
  }

  dataUpdated = true;
}

// ---------- MQTT RECONNECT ----------
void reconnect() {
  while (!client.connected()) {
    String clientId = "Arduino_Sentosa_";
    clientId += String(random(0xffff), HEX);

    Serial.print("Connecting MQTT...");

    if (client.connect(clientId.c_str())) {
      Serial.println("Connected!");

      client.subscribe(topic1);
      client.subscribe(topic2);
      client.subscribe(topic3);
    }
    else {
      Serial.print("Failed: ");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

// ---------- PROCESS DATA ----------
void processQueue() {

  // Wait until all 3 topics received
  if (!received1 || !received2 || !received3) {
    return;
  }

  float avg = (q1 + q2 + q3) / 3.0;

  float minQueue = q1;
  const char* place = "Universal";

  if (q2 < minQueue) {
    minQueue = q2;
    place = "Aquarium";
  }

  if (q3 < minQueue) {
    minQueue = q3;
    place = "Luge";
  }

  // ===== MQTT PUBLISH =====
  client.publish(topic_pub, place);

  // ===== LCD DISPLAY =====
  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print(place);
  lcd.print(" (");
  lcd.print(minQueue, 0);
  lcd.print("m)");

  lcd.setCursor(0, 1);
  lcd.print("Avg: ");
  lcd.print(avg, 0);
  lcd.print("m");

  // ===== RGB LED =====
  if (avg > 60) {
    setColor(255, 0, 0);       // Red
  }
  else if (avg >= 30) {
    setColor(255, 100, 0);     // Orange
  }
  else {
    setColor(0, 255, 180);     // Cyan Green
  }

  // ===== SERIAL MONITOR =====
  Serial.print("Q1: ");
  Serial.print(q1);

  Serial.print(" | Q2: ");
  Serial.print(q2);

  Serial.print(" | Q3: ");
  Serial.print(q3);

  Serial.print(" | Choice: ");
  Serial.print(place);

  Serial.print(" | Avg: ");
  Serial.println(avg);
}

void setup() {
  Serial.begin(9600);

  // ---------- RGB LED ----------
  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);

  setColor(0, 0, 0);

  // ---------- LCD ----------
  Wire.begin();
  lcd.init();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("Connecting...");

  // ---------- WIFI ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  if (dataUpdated) {
    dataUpdated = false;
    processQueue();
  }
}