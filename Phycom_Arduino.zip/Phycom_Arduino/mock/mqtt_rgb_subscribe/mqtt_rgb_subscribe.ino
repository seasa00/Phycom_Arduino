#include <WiFiS3.h>
#include <PubSubClient.h>

// ========== EDIT HERE ==========
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic_sub = "68070091/venus";

#define RED_PIN 9
#define GREEN_PIN 8
#define BLUE_PIN 7

// true  = Common Anode
// false = Common Cathode
const bool COMMON_ANODE = true;
// ===============================

WiFiClient wifiClient;
PubSubClient client(wifiClient);

// ---------- RGB LED ----------
void setColor(int r, int g, int b) {
  if (COMMON_ANODE) {
    r = 255 - r;
    g = 255 - g;
    b = 255 - b;
  }

  analogWrite(RED_PIN, r);
  analogWrite(GREEN_PIN, g);
  analogWrite(BLUE_PIN, b);
}

// ---------- MQTT CALLBACK ----------
void callback(char* topic, byte* payload,
              unsigned int length) {

  char message[32];

  if (length == 0 || length >= sizeof(message)) return;

  memcpy(message, payload, length);
  message[length] = '\0';

  // ===== CONVERT TO NUMBER =====
  int temperature = atoi(message);

  Serial.print("Received Temperature: ");
  Serial.println(temperature);

  // ===== EDIT IF / ELSE HERE =====
  if (temperature >= 36 && temperature <= 50) {
    setColor(255, 0, 0);   // RED
  }
  else if (temperature >= 26 && temperature <= 35) {
    setColor(0, 0, 255);   // BLUE
  }
  else if (temperature >= 10 && temperature <= 25) {
    setColor(0, 255, 0);   // GREEN
  }
  else {
    setColor(0, 0, 0);     // OFF
  }
  // =============================
}

// ---------- MQTT RECONNECT ----------
void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting MQTT...");

    String clientId = "Arduino_RGB_";
    clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("MQTT Connected!");

      // ===== MQTT SUBSCRIBE =====
      client.subscribe(topic_sub);
    }
    else {
      Serial.print("Failed, rc=");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(9600);

  // ---------- RGB LED ----------
  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);

  setColor(0, 0, 0);

  // ---------- WIFI ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(500);
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();
}