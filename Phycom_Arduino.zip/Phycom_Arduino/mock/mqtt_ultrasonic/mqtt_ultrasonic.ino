#include <WiFiS3.h>
#include <PubSubClient.h>

// ========== EDIT HERE ==========
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic = "68070091/taxi_model";

#define TRIG_PIN 10
#define ECHO_PIN 9

const unsigned long publishInterval = 1000;
// ===============================

WiFiClient wifiClient;
PubSubClient client(wifiClient);

unsigned long previousMillis = 0;

// ---------- READ DISTANCE ----------
float readDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);

  if (duration == 0) return -1;

  return duration * 0.0343 / 2.0;
}

// ---------- MQTT RECONNECT ----------
void reconnect() {
  while (!client.connected()) {
    String clientId = "Arduino_Ultrasonic_";
    clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("MQTT Connected!");
    } else {
      Serial.print("MQTT Failed: ");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(9600);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // ---------- WIFI ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  if (millis() - previousMillis >= publishInterval) {
    previousMillis = millis();

    // ===== READ SENSOR =====
    float distance = readDistance();

    if (distance < 0) {
      Serial.println("Sensor Error!");
      return;
    }

    // ===== EDIT IF / ELSE HERE =====
    const char* car;

    if (distance < 15) {
      car = "Yaris";
    }
    else if (distance <= 30) {
      car = "Altis";
    }
    else {
      car = "Accord";
    }
    // ==============================

    // ===== MQTT PUBLISH =====
    bool success = client.publish(topic, car);

    // ===== SERIAL MONITOR =====
    Serial.print("Distance: ");
    Serial.print(distance, 2);
    Serial.print(" cm | Result: ");
    Serial.print(car);
    Serial.print(" | MQTT: ");
    Serial.println(success ? "Published" : "Failed");
  }
}