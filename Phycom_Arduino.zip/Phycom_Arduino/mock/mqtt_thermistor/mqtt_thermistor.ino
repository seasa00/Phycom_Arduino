#include <WiFiS3.h>
#include <PubSubClient.h>
#include <math.h>

// ========== EDIT HERE ==========
const char* ssid = "Sea";
const char* password = "seabunyapol";

const char* mqtt_server = "phycom.it.kmitl.ac.th";
const int mqtt_port = 1883;

const char* topic = "68070091/temp";

#define THERM_PIN A0

const float R_FIXED = 10000.0;
const float R_NOMINAL = 10000.0;
const float BETA = 3950.0;

const unsigned long publishInterval = 1000;
// ===============================

WiFiClient wifiClient;
PubSubClient client(wifiClient);

unsigned long previousMillis = 0;

// ---------- READ TEMPERATURE ----------
float readTemperature() {
  int raw = analogRead(THERM_PIN);

  if (raw <= 0 || raw >= 1023) {
    return NAN;
  }

  float resistance = R_FIXED * raw / (1023.0 - raw);

  float tempK = 1.0 / (
    (1.0 / 298.15) +
    (log(resistance / R_NOMINAL) / BETA)
  );

  return tempK - 273.15;
}

// ---------- MQTT RECONNECT ----------
void reconnect() {
  while (!client.connected()) {
    String clientId = "Arduino_NTC_";
    clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("MQTT Connected!");
    } else {
      Serial.print("MQTT Failed: ");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(9600);
  analogReadResolution(10);

  // ---------- WIFI ----------
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected!");

  // ---------- MQTT ----------
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  if (millis() - previousMillis >= publishInterval) {
    previousMillis = millis();

    // ===== READ SENSOR =====
    float temperature = readTemperature();

    if (isnan(temperature)) {
      Serial.println("Sensor Error!");
      return;
    }

    // ===== CONVERT TO TEXT =====
    char message[20];
    dtostrf(temperature, 1, 2, message);

    // ===== MQTT PUBLISH =====
    bool success = client.publish(topic, message);

    // ===== SERIAL MONITOR =====
    Serial.print("Temperature: ");
    Serial.print(message);
    Serial.print(" C | MQTT: ");
    Serial.println(success ? "Published" : "Failed");
  }
}